# -*- coding: utf-8 -*-
"""Step 1: read source, clean, compute helper columns, build movie_analysis.xlsx
with live Excel formulas in Sheet2. Also dumps metrics.json for cross-file reuse."""
import json, re, datetime
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

SRC = "/Users/chi/Downloads/codex.xlsx"
OUT = "/Users/chi/Downloads/claude-movie/movie_analysis.xlsx"

wb_in = openpyxl.load_workbook(SRC, data_only=True)
ws_in = wb_in.active
rows = list(ws_in.iter_rows(values_only=True))
header = rows[0]
data = rows[1:]

MISS_BOX = {"暂无公开数据", "暂无公开评分", None, ""}

def parse_duration(v):
    if v is None: return None, "暂无公开数据"
    s = str(v).strip()
    if s in MISS_BOX: return None, s
    m = re.search(r"(\d+)", s)
    return (int(m.group(1)) if m else None), s

def parse_box(v):
    """return (numeric or None, 口径, raw_str)"""
    if v is None: return None, "缺失", "暂无公开数据"
    if isinstance(v, (int, float)):
        return float(v), "精确", v
    s = str(v).strip()
    if s in MISS_BOX: return None, "缺失", s
    m = re.search(r"([\d.]+)", s)
    if m and (s.startswith(">=") or s.startswith("≥") or ">" in s):
        return float(m.group(1)), "下限≥", s
    if m:
        return float(m.group(1)), "精确", s
    return None, "缺失", s

def parse_rating(v):
    if v is None: return None, "暂无公开评分"
    if isinstance(v, (int, float)): return float(v), v
    s = str(v).strip()
    if s in MISS_BOX or "暂无" in s: return None, s
    m = re.search(r"([\d.]+)", s)
    return (float(m.group(1)) if m else None), s

def parse_votes(v):
    if v is None: return None, "暂无公开数据", ""
    if isinstance(v, (int, float)): return int(v), v, ""
    s = str(v).strip()
    if s in MISS_BOX: return None, s, ""
    m = re.search(r"(\d+)", s)
    if m and "+" in s: return int(m.group(1)), s, "≥(下限)"
    if m: return int(m.group(1)), s, ""
    return None, s, ""

# re-release classics (very old films appearing with 2026 release dates)
RERELEASE = {"记忆碎片", "纵横四海"}

clean = []
seen = set()
for r in data:
    (title, rdate, genre, director, cast, region, dur, box, rating, votes) = r
    if title is None: continue
    if title in seen:  # dedup by title
        continue
    seen.add(title)
    date_s = rdate.strftime("%Y-%m-%d") if isinstance(rdate, (datetime.datetime, datetime.date)) else str(rdate)
    main_genre = re.split(r"[/／]", str(genre))[0].strip() if genre else "缺失"
    main_region = re.split(r"[/／]", str(region))[0].strip() if region else "缺失"
    dur_n, dur_raw = parse_duration(dur)
    box_n, box_kind, box_raw = parse_box(box)
    rat_n, rat_raw = parse_rating(rating)
    vote_n, vote_raw, vote_note = parse_votes(votes)

    notes = []
    if box_kind == "下限≥": notes.append("票房为下限值(≥)")
    if vote_note: notes.append("评分人数为下限值(≥)")
    if vote_n is not None and rat_n is None:
        notes.append("有评分人数却无评分(数据不一致)")
    if dur_n is not None and vote_n is not None and dur_n == vote_n:
        notes.append("评分人数与时长数值相同(疑似异常)")
    if title in RERELEASE:
        notes.append("疑似经典重映,评分人数为历史累计")
    note_s = "; ".join(notes)

    clean.append(dict(title=title, date=date_s, genre=genre, main_genre=main_genre,
                      region=region, main_region=main_region, director=director, cast=cast,
                      dur_raw=dur_raw, dur_n=dur_n, box_raw=box_raw, box_n=box_n,
                      box_kind=box_kind, rat_raw=rat_raw, rat_n=rat_n,
                      vote_raw=vote_raw, vote_n=vote_n, note=note_s))

# ---------------- build workbook ----------------
wb = openpyxl.Workbook()
s1 = wb.active
s1.title = "清洗后数据"

cols = ["片名","上映日期","类型","主类型","制片国家/地区","主地区","导演","主演",
        "时长原始","时长_分钟","累计票房原始(万元)","票房数值(万元)","票房口径",
        "评分原始","评分(10分制)","评分人数原始","评分人数","数据备注",
        "票房排序键","评分排序键"]
s1.append(cols)

for i, m in enumerate(clean):
    rownum = i + 2
    s1.append([
        m["title"], m["date"], m["genre"], m["main_genre"], m["region"], m["main_region"],
        m["director"], m["cast"], m["dur_raw"], m["dur_n"], m["box_raw"], m["box_n"],
        m["box_kind"], m["rat_raw"], m["rat_n"], m["vote_raw"], m["vote_n"], m["note"],
        # helper sort keys: value minus tiny row offset -> earlier row wins ties
        f'=IF(ISNUMBER(L{rownum}),L{rownum}-ROW()/10000000,"")',
        f'=IF(ISNUMBER(O{rownum}),O{rownum}-ROW()/10000000,"")',
    ])

n = len(clean)
last = n + 1  # last data row

# styling helpers
thin = Side(style="thin", color="BFBFBF")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hdr_fill = PatternFill("solid", fgColor="1F4E78")
hdr_font = Font(bold=True, color="FFFFFF", size=11)
center = Alignment(horizontal="center", vertical="center", wrap_text=True)
right = Alignment(horizontal="right", vertical="center")
left = Alignment(horizontal="left", vertical="center", wrap_text=True)

def style_header(ws, ncols, rowi=1):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=rowi, column=c)
        cell.fill = hdr_fill; cell.font = hdr_font; cell.alignment = center; cell.border = border

style_header(s1, len(cols))
s1.freeze_panes = "A2"

# numeric formats + alignment on Sheet1
for rownum in range(2, last + 1):
    s1.cell(rownum, 12).number_format = "#,##0.00"   # 票房数值 L
    s1.cell(rownum, 12).alignment = right
    s1.cell(rownum, 10).alignment = right            # 时长_分钟 J
    s1.cell(rownum, 15).number_format = "0.0"        # 评分 O
    s1.cell(rownum, 15).alignment = right
    s1.cell(rownum, 17).number_format = "#,##0"      # 评分人数 Q
    s1.cell(rownum, 17).alignment = right

widths = {"A":22,"B":12,"C":24,"D":9,"E":18,"F":11,"G":18,"H":26,"I":11,"J":9,
          "K":16,"L":14,"M":9,"N":12,"O":11,"P":12,"Q":11,"R":34,"S":12,"T":12}
for col, w in widths.items():
    s1.column_dimensions[col].width = w

# ---------------- Sheet2: 统计分析 (formulas) ----------------
s2 = wb.create_sheet("统计分析")
DR = f"清洗后数据!"
def rng(col): return f"{DR}{col}2:{col}{last}"

big = Font(bold=True, size=13, color="1F4E78")
sub = Font(bold=True, size=11, color="FFFFFF")
subfill = PatternFill("solid", fgColor="2E75B6")

r = 1
s2.cell(r,1,"近期影片数据统计分析（公式实时计算）").font = big
r += 2

# Block A: overall
s2.cell(r,1,"一、总体指标").font = Font(bold=True, size=12)
r += 1
overall = [
    ("样本量(影片总数)", f"=COUNTA({rng('A')})", "0"),
    ("有票房数值的记录数", f"=COUNT({rng('L')})", "0"),
    ("其中票房精确值数", f'=COUNTIF({rng("M")},"精确")', "0"),
    ("票房为下限值(≥)数", f'=COUNTIF({rng("M")},"下限≥")', "0"),
    ("票房缺失数", f'=COUNTIF({rng("M")},"缺失")', "0"),
    ("可得票房合计(万元,含下限)", f"=SUM({rng('L')})", "#,##0.00"),
    ("有评分的记录数", f"=COUNT({rng('O')})", "0"),
    ("评分缺失数", f"=COUNTBLANK({rng('O')})", "0"),
    ("全样本平均评分", f"=AVERAGE({rng('O')})", "0.0"),
    ("平均时长(分钟)", f"=AVERAGE({rng('J')})", "0.0"),
]
for name, f, fmt in overall:
    s2.cell(r,1,name); c = s2.cell(r,2,f); c.number_format = fmt; c.alignment = right
    r += 1
r += 1

# Block B: by main genre
s2.cell(r,1,"二、按主类型：影片数 / 平均票房(万元) / 平均评分 / 有评分样本数").font = Font(bold=True, size=12)
r += 1
ghead = ["主类型","影片数","平均票房(万元)","平均评分","有评分样本数"]
for j,h in enumerate(ghead):
    cell = s2.cell(r,j+1,h); cell.fill=subfill; cell.font=sub; cell.alignment=center; cell.border=border
r += 1
genres = sorted({m["main_genre"] for m in clean},
                key=lambda g: -sum(1 for m in clean if m["main_genre"]==g))
gstart = r
for g in genres:
    s2.cell(r,1,g)
    s2.cell(r,2,f'=COUNTIF({rng("D")},A{r})').alignment=right
    c=s2.cell(r,3,f'=IFERROR(AVERAGEIF({rng("D")},A{r},{rng("L")}),"无数据")'); c.number_format="#,##0.00"; c.alignment=right
    c=s2.cell(r,4,f'=IFERROR(AVERAGEIF({rng("D")},A{r},{rng("O")}),"无数据")'); c.number_format="0.0"; c.alignment=right
    s2.cell(r,5,f'=COUNTIFS({rng("D")},A{r},{rng("O")},">=0")').alignment=right
    r += 1
r += 1

# Block C: box office Top5
s2.cell(r,1,"三、票房 Top5（按票房数值降序；含下限值已标注口径）").font = Font(bold=True, size=12)
r += 1
for j,h in enumerate(["排名","片名","票房(万元)","口径"]):
    cell=s2.cell(r,j+1,h); cell.fill=subfill; cell.font=sub; cell.alignment=center; cell.border=border
r += 1
for k in range(1,6):
    s2.cell(r,1,k).alignment=right
    s2.cell(r,2,f'=INDEX({rng("A")},MATCH(LARGE({rng("S")},{k}),{rng("S")},0))')
    c=s2.cell(r,3,f'=INDEX({rng("L")},MATCH(LARGE({rng("S")},{k}),{rng("S")},0))'); c.number_format="#,##0.00"; c.alignment=right
    s2.cell(r,4,f'=INDEX({rng("M")},MATCH(LARGE({rng("S")},{k}),{rng("S")},0))').alignment=center
    r += 1
r += 1

# Block D: rating Top5
s2.cell(r,1,"四、评分 Top5（按评分降序）").font = Font(bold=True, size=12)
r += 1
for j,h in enumerate(["排名","片名","评分(10分制)"]):
    cell=s2.cell(r,j+1,h); cell.fill=subfill; cell.font=sub; cell.alignment=center; cell.border=border
r += 1
for k in range(1,6):
    s2.cell(r,1,k).alignment=right
    s2.cell(r,2,f'=INDEX({rng("A")},MATCH(LARGE({rng("T")},{k}),{rng("T")},0))')
    c=s2.cell(r,3,f'=INDEX({rng("O")},MATCH(LARGE({rng("T")},{k}),{rng("T")},0))'); c.number_format="0.0"; c.alignment=right
    r += 1
r += 1

# Block E: by region (main region)
s2.cell(r,1,"五、各制片地区（主地区）：影片数 / 可得总票房(万元)").font = Font(bold=True, size=12)
r += 1
for j,h in enumerate(["主地区","影片数","可得总票房(万元)"]):
    cell=s2.cell(r,j+1,h); cell.fill=subfill; cell.font=sub; cell.alignment=center; cell.border=border
r += 1
regions = sorted({m["main_region"] for m in clean},
                 key=lambda x: -sum(1 for m in clean if m["main_region"]==x))
for reg in regions:
    s2.cell(r,1,reg)
    s2.cell(r,2,f'=COUNTIF({rng("F")},A{r})').alignment=right
    c=s2.cell(r,3,f'=SUMIF({rng("F")},A{r},{rng("L")})'); c.number_format="#,##0.00"; c.alignment=right
    r += 1

for col,w in {"A":24,"B":14,"C":18,"D":12,"E":14}.items():
    s2.column_dimensions[col].width = w

wb.save(OUT)
print("saved", OUT)

# ---------------- compute metrics in Python (mirror formulas) for cross-file ----------------
box_vals = [m for m in clean if m["box_n"] is not None]
rat_vals = [m for m in clean if m["rat_n"] is not None]
def avg(xs): return sum(xs)/len(xs) if xs else None

genre_stats=[]
for g in genres:
    gm=[m for m in clean if m["main_genre"]==g]
    gb=[m["box_n"] for m in gm if m["box_n"] is not None]
    gr=[m["rat_n"] for m in gm if m["rat_n"] is not None]
    genre_stats.append(dict(genre=g,count=len(gm),
        avg_box=(avg(gb) if gb else None), avg_rat=(avg(gr) if gr else None),
        rated=len(gr)))

region_stats=[]
for reg in regions:
    rm=[m for m in clean if m["main_region"]==reg]
    rb=[m["box_n"] for m in rm if m["box_n"] is not None]
    region_stats.append(dict(region=reg,count=len(rm),total_box=sum(rb)))

box_top=sorted(box_vals,key=lambda m:(-m["box_n"], clean.index(m)))[:5]
rat_top=sorted(rat_vals,key=lambda m:(-m["rat_n"], clean.index(m)))[:5]

metrics=dict(
    n=len(clean),
    box_have=len(box_vals),
    box_exact=sum(1 for m in clean if m["box_kind"]=="精确"),
    box_lower=sum(1 for m in clean if m["box_kind"]=="下限≥"),
    box_missing=sum(1 for m in clean if m["box_kind"]=="缺失"),
    box_total=sum(m["box_n"] for m in box_vals),
    box_exact_total=sum(m["box_n"] for m in clean if m["box_kind"]=="精确"),
    rat_have=len(rat_vals),
    rat_missing=len(clean)-len(rat_vals),
    rat_avg=avg([m["rat_n"] for m in rat_vals]),
    dur_avg=avg([m["dur_n"] for m in clean if m["dur_n"] is not None]),
    date_min=min(m["date"] for m in clean),
    date_max=max(m["date"] for m in clean),
    genre_stats=genre_stats,
    region_stats=region_stats,
    box_top=[dict(title=m["title"],box=m["box_n"],kind=m["box_kind"]) for m in box_top],
    box_all=[dict(title=m["title"],box=m["box_n"],kind=m["box_kind"])
             for m in sorted(box_vals,key=lambda x:-x["box_n"])],
    src_sheet=ws_in.title,
    rat_top=[dict(title=m["title"],rat=m["rat_n"]) for m in rat_top],
    anomalies=[dict(title=m["title"],note=m["note"]) for m in clean if m["note"]],
)
with open("/Users/chi/Downloads/claude-movie/metrics.json","w") as f:
    json.dump(metrics,f,ensure_ascii=False,indent=2)
print(json.dumps(metrics,ensure_ascii=False,indent=2))
