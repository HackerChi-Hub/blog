# -*- coding: utf-8 -*-
"""Step 2: charts + movie_report.docx + movie_summary.pptx, all from metrics.json."""
import json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "Songti SC", "STHeiti"]
plt.rcParams["axes.unicode_minus"] = False
BLUE="#1F4E78"; LBLUE="#2E75B6"; ORANGE="#E07B39"; GREY="#BFBFBF"
PAL=["#1F4E78","#2E75B6","#5B9BD5","#9DC3E6","#E07B39","#F2A65A","#A5A5A5","#C9C9C9"]

D="/Users/chi/Downloads/claude-movie/"
m=json.load(open(D+"metrics.json"))
def yi(wan): return wan/10000.0  # 万元 -> 亿元

# ---------- charts ----------
# 1 genre counts
gs=sorted(m["genre_stats"], key=lambda x:-x["count"])
fig,ax=plt.subplots(figsize=(7,4.2))
bars=ax.bar([g["genre"] for g in gs],[g["count"] for g in gs],color=BLUE)
for b in bars: ax.text(b.get_x()+b.get_width()/2,b.get_height()+0.1,int(b.get_height()),ha="center",fontsize=10)
ax.set_ylabel("影片数(部)"); ax.set_title("主类型分布（按首要类型，n=30）",fontweight="bold")
ax.spines[["top","right"]].set_visible(False)
plt.tight_layout(); plt.savefig(D+"charts/genre.png",dpi=150); plt.close()

# 2 region pie
rs=sorted(m["region_stats"],key=lambda x:-x["count"])
fig,ax=plt.subplots(figsize=(6.2,4.6))
ax.pie([r["count"] for r in rs],labels=[f'{r["region"]}\n{r["count"]}部' for r in rs],
       autopct="%1.0f%%",colors=PAL,startangle=90,textprops={"fontsize":10})
ax.set_title("各制片地区影片数量占比（按主地区）",fontweight="bold")
plt.tight_layout(); plt.savefig(D+"charts/region.png",dpi=150); plt.close()

# 3 box office (8 with data)
import json as _j
clean_box=sorted([b for b in m["box_top"]],key=lambda x:x["box"])  # only top5; need all 8 -> recompute from genre? store separately
# rebuild full box list from metrics is not stored; reload region not enough -> read source quick
# Instead use box_top (5) + we know full set; simplest: chart the 8 from a dedicated list
# We stored only top5; extend by reading metrics 'box_all' if present else use top5
box_all=m.get("box_all") or m["box_top"]
box_all=sorted(box_all,key=lambda x:x["box"])
fig,ax=plt.subplots(figsize=(7.4,4.4))
colors=[ORANGE if b["kind"]=="下限≥" else BLUE for b in box_all]
bars=ax.barh([b["title"] for b in box_all],[yi(b["box"]) for b in box_all],color=colors)
for b,it in zip(bars,box_all):
    lab=f'{yi(it["box"]):.2f}亿'+("(≥)" if it["kind"]=="下限≥" else "")
    ax.text(b.get_width(),b.get_y()+b.get_height()/2,"  "+lab,va="center",fontsize=9)
ax.set_xlabel("累计票房(亿元)"); ax.set_title("有票房数据影片票房榜（蓝=精确，橙=下限≥）",fontweight="bold")
ax.spines[["top","right"]].set_visible(False); ax.set_xlim(0,max(yi(b["box"]) for b in box_all)*1.18)
plt.tight_layout(); plt.savefig(D+"charts/box.png",dpi=150); plt.close()

# 4 rating top
rt=sorted(m["rat_top"],key=lambda x:x["rat"])
fig,ax=plt.subplots(figsize=(7.4,3.8))
bars=ax.barh([r["title"] for r in rt],[r["rat"] for r in rt],color=LBLUE)
for b in bars: ax.text(b.get_width(),b.get_y()+b.get_height()/2,f'  {b.get_width():.1f}',va="center",fontsize=10)
ax.set_xlabel("评分(10分制)"); ax.set_xlim(0,10); ax.set_title("评分 Top5",fontweight="bold")
ax.spines[["top","right"]].set_visible(False)
plt.tight_layout(); plt.savefig(D+"charts/rating.png",dpi=150); plt.close()
print("charts done")

# ================= DOCX =================
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

doc=Document()
# set CJK default font
st=doc.styles["Normal"]; st.font.name="Songti SC"; st.font.size=Pt(11)
st.element.rPr.rFonts.set(qn("w:eastAsia"),"Songti SC")

def set_cjk(run,name="Songti SC"):
    run.font.name=name; r=run._element.rPr.rFonts; r.set(qn("w:eastAsia"),name)

t=doc.add_heading("近期上映影片数据分析报告",level=0)
for run in t.runs: set_cjk(run,"Heiti SC" )
p=doc.add_paragraph(f'数据来源：codex.xlsx（recent_movies_2026-05-30）　|　覆盖区间：{m["date_min"]} 至 {m["date_max"]}　|　样本量：{m["n"]} 部')
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
for run in p.runs: run.font.size=Pt(9); run.font.color.rgb=RGBColor(0x66,0x66,0x66)

def H(txt,lvl=1):
    h=doc.add_heading(txt,level=lvl)
    for run in h.runs: set_cjk(run,"Heiti SC"); run.font.color.rgb=RGBColor(0x1F,0x4E,0x78)
    return h
def P(txt):
    p=doc.add_paragraph(txt)
    for run in p.runs: set_cjk(run)
    return p

box_miss_pct=m["box_missing"]/m["n"]*100
rat_miss_pct=m["rat_missing"]/m["n"]*100
juqing=[g for g in m["genre_stats"] if g["genre"]=="剧情"][0]
mainland=[r for r in m["region_stats"] if r["region"]=="中国大陆"][0]
top1=m["box_top"][0]; top2=m["box_top"][1]
rtop1=m["rat_top"][0]

H("一、概述与数据质量",1)
P(f'本报告基于 codex.xlsx 中“{m.get("src_sheet","recent_movies")}”近期影片清单，'
  f'共 {m["n"]} 条记录，上映日期集中在 {m["date_min"]} 至 {m["date_max"]} 的约一个月窗口内，'
  f'字段包括片名、上映日期、类型、导演、主演、制片国家/地区、时长、累计票房（万元）、'
  f'评分（10分制）与评分人数。经去重（按片名）后保留全部 {m["n"]} 条有效记录，未发现重复行。')
P(f'数据质量是本次分析最需要前置说明的部分。最突出的问题是票房字段严重缺失：'
  f'{m["n"]} 部影片中仅 {m["box_have"]} 部有票房数值，且其中只有 {m["box_exact"]} 部为精确值，'
  f'另有 {m["box_lower"]} 部仅以“≥5000”“≥7379.82”等下限形式给出；其余 {m["box_missing"]} 部'
  f'（占 {box_miss_pct:.1f}%）标注为“暂无公开数据”。评分字段同样有 {m["rat_missing"]} 部缺失'
  f'（占 {rat_miss_pct:.1f}%），有效评分 {m["rat_have"]} 部。清洗时一律保留原始“暂无公开数据/暂无公开评分”'
  f'标记，未对任何缺失值做填补。')
P('此外发现若干异常需读者警惕：（1）《钟馗》《森林之声》存在“有评分人数却无评分”的逻辑矛盾，'
  '其中《森林之声》评分人数(87)恰等于其时长(87分钟)，疑为串列录入错误；（2）《纵横四海》(8.8分)、'
  '《记忆碎片》(8.7分)评分极高且评分人数达数十万，结合影片本身判断应为经典老片重映，'
  '其评分人数为历史累计而非本轮新增，不能等同于新片市场口碑；（3）5 部影片票房为下限值，'
  '故所有票房合计与排名均为“保守下限”，真实值只会更高。')

H("二、分析口径与方法说明",1)
P('为在多值字段上得到可比口径，本报告作如下约定：（1）“主类型”取“类型”字段中以斜杠分隔的'
  '首要标签（如“悬疑 / 犯罪 / 剧情”记为悬疑），用于类型层面的聚合；（2）“主地区”取“制片国家/地区”'
  '的首个地区（如“中国大陆 / 中国香港”记为中国大陆），以避免合拍片被拆成大量碎片化分组；'
  '（3）票房统计同时纳入精确值与下限值，并在数据表中以“票房口径”列分别标注“精确/下限≥/缺失”，'
  '所有合计与平均均可据此回溯；（4）平均评分仅基于有公开评分的影片，缺失项不参与计算、也不填补。'
  '上述口径在配套的 movie_analysis.xlsx 中均以 Excel 公式（COUNTIF、AVERAGEIF、SUMIF、'
  'LARGE+INDEX/MATCH 等）实现，可逐格核验，确保三个交付文件中同一指标数值完全一致。')

H("三、票房表现分析",1)
P(f'在 {m["box_have"]} 部有票房数值的影片中，《{top1["title"]}》以 {top1["box"]:,.0f} 万元'
  f'（约 {yi(top1["box"]):.2f} 亿元，精确值）高居榜首，且断层领先；第二位《{top2["title"]}》'
  f'为 {top2["box"]:,.0f} 万元（约 {yi(top2["box"]):.2f} 亿元）。两者均为精确披露票房，'
  f'可信度较高。其余进入票房榜的影片（《错过了，遗憾吗？》《寒战1994》《10间敢死队》等）'
  f'多为“≥5000 万元”量级的下限值，彼此并列、难以精确排序。')
P(f'若仅以 3 部精确票房计，合计约 {yi(m["box_exact_total"]):.2f} 亿元；若把 5 部下限值一并纳入，'
  f'可得票房合计约 {yi(m["box_total"]):.2f} 亿元——但需强调这是下限，真实总票房高于此数。'
  f'由于近七成影片票房缺失，本窗口的整体市场规模无法从该数据集得出可靠结论。')

H("四、评分与口碑分析",1)
P(f'有效评分 {m["rat_have"]} 部，全样本平均评分 {m["rat_avg"]:.2f} 分，整体处于中上水平。'
  f'评分 Top5 为：《{m["rat_top"][0]["title"]}》{m["rat_top"][0]["rat"]:.1f}、'
  f'《{m["rat_top"][1]["title"]}》{m["rat_top"][1]["rat"]:.1f}、'
  f'《{m["rat_top"][2]["title"]}》{m["rat_top"][2]["rat"]:.1f}、'
  f'《{m["rat_top"][3]["title"]}》{m["rat_top"][3]["rat"]:.1f}、'
  f'《{m["rat_top"][4]["title"]}》{m["rat_top"][4]["rat"]:.1f}。'
  f'其中第 2、3 位为疑似重映经典，剔除后真正属于本轮新片的口碑高点是《{rtop1["title"]}》(9.2)。'
  f'另一端，《错过了，遗憾吗？》以 4.5 分为全样本最低，是口碑明显失利的代表。')

H("五、类型与地区分布",1)
P(f'按首要类型划分，剧情片以 {juqing["count"]} 部（占 {juqing["count"]/m["n"]*100:.1f}%）'
  f'压倒性主导本窗口，其有效评分均值 {juqing["avg_rat"]:.2f} 分，在有足够样本的类型中最高；'
  f'动画、喜剧、悬疑、纪录片各 3 部，动作、爱情、惊悚为长尾。值得注意的是动画与纪录片'
  f'几乎没有公开评分（评分样本为 0），属于“高产出但低数据透明度”的类型。')
P(f'制片地区上，中国大陆以 {mainland["count"]} 部（占 {mainland["count"]/m["n"]*100:.1f}%）'
  f'占据半壁江山，且贡献了几乎全部可得票房（约 {yi(mainland["total_box"]):.2f} 亿元下限）；'
  f'美国 5 部、中国台湾 4 部次之，中国香港、英国各 2 部，爱尔兰 1 部。中国台湾影片虽有 4 部，'
  f'但票房与评分披露极少，市场数据近乎空白。')

H("六、关联洞察：票房 vs 评分",1)
P(f'最值得关注的一点是：《{top1["title"]}》同时拿下票房榜第一（{yi(top1["box"]):.2f} 亿元）'
  f'与评分榜第一（9.2 分），形成“叫好又叫座”的双冠，是本窗口口碑驱动票房的典型样本。'
  f'与之形成鲜明对照的是《错过了，遗憾吗？》：评分仅 4.5（全样本垫底），却仍录得 ≥7379 万元的票房，'
  f'说明在短期内话题度、档期或主演阵容可以把低口碑影片推上一定票房——但这类“口碑透支型”表现通常缺乏后劲。'
  f'综合判断：本数据集中能同时验证的高质量样本太少（精确票房仅 3 部），'
  f'因此“高分必然高票房”不能一概而论，唯一可确证的强关联个案是头部影片的口碑票房双优。')

H("七、结论与风险提示",1)
P(f'结论：本窗口（{m["date_min"]} 至 {m["date_max"]}）共 {m["n"]} 部影片，'
  f'呈现“剧情片+中国大陆制作”双主导格局；《{top1["title"]}》以票房口碑双冠领跑，'
  f'平均评分 {m["rat_avg"]:.2f}、平均时长 {m["dur_avg"]:.0f} 分钟。')
rp=doc.add_paragraph()
r=rp.add_run('⚠ 风险提示：票房字段缺失率高达 %.0f%% 且含 5 个下限值，本报告所有票房合计与排名均为保守下限，不可作为绝对市场规模或精确排名的依据，决策前需补充权威票房数据源。'%box_miss_pct)
set_cjk(r); r.bold=True; r.font.color.rgb=RGBColor(0xC0,0x00,0x00)

# ---- table 1: 总体指标 ----
H("附表一　总体指标",2)
rows=[("指标","数值"),
      ("样本量(部)",f'{m["n"]}'),
      ("有票房数值(部)",f'{m["box_have"]}（精确{m["box_exact"]}+下限{m["box_lower"]}）'),
      ("票房缺失(部)",f'{m["box_missing"]}（{box_miss_pct:.1f}%）'),
      ("可得票房合计",f'{m["box_total"]:,.2f} 万元（≈{yi(m["box_total"]):.2f}亿，下限）'),
      ("有评分(部)",f'{m["rat_have"]}（缺失{m["rat_missing"]}）'),
      ("全样本平均评分",f'{m["rat_avg"]:.2f}'),
      ("平均时长(分钟)",f'{m["dur_avg"]:.1f}')]
tb=doc.add_table(rows=len(rows),cols=2); tb.style="Light Grid Accent 1"
for i,(a,b) in enumerate(rows):
    for j,val in enumerate((a,b)):
        cell=tb.cell(i,j); cell.text=""
        run=cell.paragraphs[0].add_run(val); set_cjk(run)
        if i==0: run.bold=True

# ---- table 2: 主类型统计 ----
H("附表二　按主类型统计",2)
gg=sorted(m["genre_stats"],key=lambda x:-x["count"])
tb2=doc.add_table(rows=len(gg)+1,cols=5); tb2.style="Light Grid Accent 1"
hd=["主类型","影片数","平均票房(万元)","平均评分","有评分样本"]
for j,h in enumerate(hd):
    run=tb2.cell(0,j).paragraphs[0].add_run(h); set_cjk(run); run.bold=True
for i,g in enumerate(gg,1):
    vals=[g["genre"],str(g["count"]),
          (f'{g["avg_box"]:,.2f}' if g["avg_box"] is not None else "无数据"),
          (f'{g["avg_rat"]:.1f}' if g["avg_rat"] is not None else "无数据"),
          str(g["rated"])]
    for j,v in enumerate(vals):
        run=tb2.cell(i,j).paragraphs[0].add_run(v); set_cjk(run)

doc.save(D+"movie_report.docx")
print("docx done")

# ================= PPTX =================
from pptx import Presentation
from pptx.util import Inches as I, Pt as PT, Emu
from pptx.dml.color import RGBColor as RC
from pptx.enum.text import PP_ALIGN

prs=Presentation(); prs.slide_width=I(13.333); prs.slide_height=I(7.5)
SW,SH=prs.slide_width,prs.slide_height
NAVY=RC(0x1F,0x4E,0x78); GREYC=RC(0x59,0x59,0x59); WHITE=RC(0xFF,0xFF,0xFF); ORG=RC(0xE0,0x7B,0x39)
blank=prs.slide_layouts[6]

def slide(): return prs.slides.add_slide(blank)
def box(s,l,t,w,h): return s.shapes.add_textbox(I(l),I(t),I(w),I(h)).text_frame
def setrun(p,txt,size,bold=False,color=NAVY,font="Heiti SC"):
    r=p.add_run(); r.text=txt; r.font.size=PT(size); r.font.bold=bold; r.font.color.rgb=color
    r.font.name=font; return r
def bandtop(s,color=NAVY,h=0.18):
    sh=s.shapes.add_shape(1,0,0,SW,I(h)); sh.fill.solid(); sh.fill.fore_color.rgb=color; sh.line.fill.background()

def title_slide(s,title,sub):
    bg=s.shapes.add_shape(1,0,0,SW,SH); bg.fill.solid(); bg.fill.fore_color.rgb=NAVY; bg.line.fill.background()
    tf=box(s,0.9,2.5,11.5,2.0); p=tf.paragraphs[0]; setrun(p,title,40,True,WHITE)
    p2=tf.add_paragraph(); setrun(p2,sub,18,False,RC(0xCF,0xE2,0xF3),"Songti SC")

def content_head(s,title):
    bandtop(s)
    tf=box(s,0.6,0.35,12,0.9); p=tf.paragraphs[0]; setrun(p,title,28,True,NAVY)

def bullets(s,items,l=0.8,t=1.5,w=11.5,h=5.2,size=18):
    tf=box(s,l,t,w,h); tf.word_wrap=True
    for i,(txt,lvl) in enumerate(items):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.level=lvl
        setrun(p,("• " if lvl==0 else "– ")+txt,size-(2 if lvl else 0),lvl==0,
               NAVY if lvl==0 else GREYC,"Songti SC")
        p.space_after=PT(8)

def pic(s,path,l,t,w): s.shapes.add_picture(path,I(l),I(t),width=I(w))

# 1 cover
s=slide(); title_slide(s,"近期上映影片数据分析",
    f'数据来源 codex.xlsx　|　{m["date_min"]} 至 {m["date_max"]}　|　样本 {m["n"]} 部\n黑粉科技 · 数据分析　{m["date_max"]}')

# 2 核心结论
s=slide(); content_head(s,"核心结论")
bullets(s,[
 (f'样本 {m["n"]} 部，集中在 {m["date_min"]} ~ {m["date_max"]} 约一个月窗口',0),
 (f'《{top1["title"]}》票房口碑双冠：{yi(top1["box"]):.2f} 亿元 + 9.2 分',0),
 (f'剧情片主导（{juqing["count"]} 部）、中国大陆制作主导（{mainland["count"]} 部）',0),
 (f'全样本平均评分 {m["rat_avg"]:.2f}，平均时长 {m["dur_avg"]:.0f} 分钟',0),
 (f'数据缺口大：票房缺失 {box_miss_pct:.0f}%、评分缺失 {rat_miss_pct:.0f}%',0),
 ('一切票房合计/排名均为“保守下限”，需补充权威数据',1),
])

# 3 数据质量
s=slide(); content_head(s,"数据质量与异常提示")
bullets(s,[
 (f'票房：仅 {m["box_have"]}/{m["n"]} 部有值，其中精确仅 {m["box_exact"]} 部，{m["box_lower"]} 部为下限(≥)',0),
 (f'评分：{m["rat_have"]} 部有效，{m["rat_missing"]} 部“暂无公开评分”',0),
 ('《钟馗》《森林之声》有评分人数却无评分（逻辑矛盾）',0),
 ('《森林之声》评分人数(87)=时长(87分钟)，疑似串列错误',1),
 ('《纵横四海》《记忆碎片》疑为经典重映，评分人数为历史累计',0),
 ('清洗原则：保留原始缺失标记，不做任何填补',0),
])

# 4 票房榜
s=slide(); content_head(s,"票房榜（蓝=精确，橙=下限≥）")
pic(s,D+"charts/box.png",0.7,1.4,8.3)
bullets(s,[
 (f'冠军《{top1["title"]}》{yi(top1["box"]):.2f} 亿（精确）',0),
 (f'亚军《{top2["title"]}》{yi(top2["box"]):.2f} 亿（精确）',0),
 ('其余多为 ≥0.5 亿下限值，难精确排序',0),
 (f'可得合计 ≈{yi(m["box_total"]):.2f} 亿（下限）',1),
],l=9.1,t=1.6,w=3.9,size=15)

# 5 评分榜
s=slide(); content_head(s,"评分榜 Top5")
pic(s,D+"charts/rating.png",0.7,1.5,8.3)
bullets(s,[
 (f'最高《{rtop1["title"]}》9.2（新片口碑顶点）',0),
 ('8.8/8.7 两部为疑似重映经典',0),
 ('剔除重映后新片口碑梯队集中在 7~7.5',0),
 ('全样本均分 %.2f'%m["rat_avg"],0),
],l=9.1,t=1.7,w=3.9,size=15)

# 6 类型分布
s=slide(); content_head(s,"类型分布")
pic(s,D+"charts/genre.png",0.7,1.5,8.3)
bullets(s,[
 (f'剧情片 {juqing["count"]} 部，占 {juqing["count"]/m["n"]*100:.0f}%',0),
 (f'剧情类有效均分 {juqing["avg_rat"]:.1f}，类型最高',0),
 ('动画/纪录片几乎无公开评分',0),
 ('动作/爱情/惊悚为长尾',0),
],l=9.1,t=1.7,w=3.9,size=15)

# 7 地区分布
s=slide(); content_head(s,"制片地区分布")
pic(s,D+"charts/region.png",0.7,1.5,7.2)
bullets(s,[
 (f'中国大陆 {mainland["count"]} 部，占 {mainland["count"]/m["n"]*100:.0f}%',0),
 ('美国 5、中国台湾 4 次之',0),
 (f'大陆贡献几乎全部可得票房 ≈{yi(mainland["total_box"]):.2f} 亿',0),
 ('台湾影片票房/评分披露极少',1),
],l=8.3,t=1.7,w=4.7,size=15)

# 8 总结
s=slide(); content_head(s,"总结与风险提示")
bullets(s,[
 ('格局：剧情片 + 中国大陆制作双主导',0),
 (f'标杆：《{top1["title"]}》票房口碑双冠，口碑驱动票房范例',0),
 ('反例：《错过了，遗憾吗？》4.5 分仍有票房，口碑透支型',0),
 ('洞察：精确样本太少，"高分=高票房"不能一概而论',0),
],t=1.4,h=2.6)
warn=s.shapes.add_shape(1,I(0.8),I(4.6),I(11.7),I(1.4))
warn.fill.solid(); warn.fill.fore_color.rgb=RC(0xFB,0xE4,0xD5); warn.line.color.rgb=ORG
tf=warn.text_frame; tf.word_wrap=True; p=tf.paragraphs[0]
setrun(p,f'⚠ 风险提示：票房缺失 {box_miss_pct:.0f}% 且含下限值，所有票房合计与排名均为保守下限，'
         f'不可作为绝对市场规模或精确排名依据，决策前须补充权威票房数据。',16,True,RC(0xA0,0x40,0x00),"Songti SC")

prs.save(D+"movie_summary.pptx")
print("pptx done")
