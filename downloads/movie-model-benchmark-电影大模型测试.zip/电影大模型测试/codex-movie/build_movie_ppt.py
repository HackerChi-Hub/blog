import json
from pathlib import Path

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Cm, Pt


BASE_DIR = Path("/Users/chi/codex-movie")
STATS_PATH = BASE_DIR / "movie_stats.json"
PPTX_OUT = BASE_DIR / "movie_summary.pptx"

NAVY = RGBColor(25, 49, 83)
BLUE = RGBColor(44, 112, 180)
RED = RGBColor(205, 55, 55)
GOLD = RGBColor(230, 168, 64)
GREEN = RGBColor(60, 145, 105)
GRAY = RGBColor(96, 105, 117)
LIGHT = RGBColor(244, 247, 251)
INK = RGBColor(30, 34, 40)


def fmt_money(v):
    if v is None:
        return "缺失"
    return f"{v:,.2f}万元"


def fmt_score(v):
    if v is None:
        return "缺失"
    return f"{v:.1f}分"


def add_text(slide, text, x, y, w, h, size=18, bold=False, color=INK, align=None):
    box = slide.shapes.add_textbox(Cm(x), Cm(y), Cm(w), Cm(h))
    frame = box.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.margin_left = Cm(0.05)
    frame.margin_right = Cm(0.05)
    frame.vertical_anchor = MSO_ANCHOR.TOP
    p = frame.paragraphs[0]
    if align:
        p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return box


def add_title(slide, title, subtitle=None):
    add_text(slide, title, 1.1, 0.65, 24, 1.0, size=26, bold=True, color=NAVY)
    if subtitle:
        add_text(slide, subtitle, 1.15, 1.65, 23, 0.6, size=11, color=GRAY)
    line = slide.shapes.add_shape(1, Cm(1.12), Cm(2.25), Cm(24.5), Cm(0.04))
    line.fill.solid()
    line.fill.fore_color.rgb = RGBColor(210, 218, 230)
    line.line.fill.background()


def add_metric(slide, label, value, x, y, w=5.4, h=2.2, color=BLUE):
    shape = slide.shapes.add_shape(1, Cm(x), Cm(y), Cm(w), Cm(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = LIGHT
    shape.line.color.rgb = RGBColor(218, 226, 238)
    add_text(slide, value, x + 0.35, y + 0.35, w - 0.7, 0.75, size=22, bold=True, color=color)
    add_text(slide, label, x + 0.35, y + 1.25, w - 0.7, 0.55, size=10, color=GRAY)


def add_bullets(slide, items, x, y, w, h, size=16):
    box = slide.shapes.add_textbox(Cm(x), Cm(y), Cm(w), Cm(h))
    frame = box.text_frame
    frame.clear()
    frame.word_wrap = True
    for idx, item in enumerate(items):
        p = frame.paragraphs[0] if idx == 0 else frame.add_paragraph()
        p.text = item
        p.level = 0
        p.font.name = "Microsoft YaHei"
        p.font.size = Pt(size)
        p.font.color.rgb = INK
        p.space_after = Pt(8)
    return box


def add_bar_chart(slide, title, categories, values, x, y, w, h, color=BLUE, horizontal=True):
    chart_data = CategoryChartData()
    chart_data.categories = categories
    chart_data.add_series(title, values)
    chart_type = XL_CHART_TYPE.BAR_CLUSTERED if horizontal else XL_CHART_TYPE.COLUMN_CLUSTERED
    chart = slide.shapes.add_chart(chart_type, Cm(x), Cm(y), Cm(w), Cm(h), chart_data).chart
    chart.has_legend = False
    chart.chart_title.has_text_frame = True
    chart.chart_title.text_frame.text = title
    chart.chart_title.text_frame.paragraphs[0].runs[0].font.size = Pt(13)
    plot = chart.plots[0]
    plot.has_data_labels = True
    plot.data_labels.font.size = Pt(9)
    plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
    series = plot.series[0]
    series.format.fill.solid()
    series.format.fill.fore_color.rgb = color
    chart.value_axis.tick_labels.font.size = Pt(9)
    chart.category_axis.tick_labels.font.size = Pt(9)
    return chart


def add_pie_chart(slide, title, categories, values, x, y, w, h):
    chart_data = CategoryChartData()
    chart_data.categories = categories
    chart_data.add_series(title, values)
    chart = slide.shapes.add_chart(XL_CHART_TYPE.PIE, Cm(x), Cm(y), Cm(w), Cm(h), chart_data).chart
    chart.has_legend = True
    chart.legend.include_in_layout = False
    chart.chart_title.has_text_frame = True
    chart.chart_title.text_frame.text = title
    plot = chart.plots[0]
    plot.has_data_labels = True
    plot.data_labels.show_percentage = True
    plot.data_labels.position = XL_LABEL_POSITION.BEST_FIT
    plot.data_labels.font.size = Pt(9)
    return chart


def build_deck(stats):
    prs = Presentation()
    prs.slide_width = Cm(26.67)
    prs.slide_height = Cm(15)
    blank = prs.slide_layouts[6]

    # 1 Cover
    slide = prs.slides.add_slide(blank)
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = RGBColor(248, 250, 253)
    add_text(slide, "2026年5月新片数据分析", 1.25, 1.25, 18, 1.2, size=32, bold=True, color=NAVY)
    add_text(slide, "基于 codex.xlsx 清洗后的30部影片样本", 1.3, 2.55, 16, 0.7, size=14, color=GRAY)
    add_metric(slide, "清洗后有效记录", f"{stats['valid_count']}部", 1.35, 5.15, color=BLUE)
    add_metric(slide, "可确认下限总票房", fmt_money(stats["box_office_total_lower_bound"]), 7.15, 5.15, w=6.4, color=RED)
    add_metric(slide, "有评分影片", f"{stats['scored_count']}部", 13.9, 5.15, color=GREEN)
    add_text(slide, "票房含精确值与 >= 下限值；缺失值不补数。", 1.35, 12.95, 20, 0.55, size=10, color=GRAY)

    # 2 Core conclusions
    slide = prs.slides.add_slide(blank)
    add_title(slide, "核心结论：票房头部集中，口碑并非完全同步", "同一指标与 Excel/Word 保持一致")
    add_metric(slide, "票房Top1", stats["top_box"][0]["片名"], 1.2, 3.0, w=7.2, color=RED)
    add_metric(slide, "评分Top1", f"{stats['top_rating'][0]['片名']} {fmt_score(stats['top_rating'][0]['评分'])}", 9.0, 3.0, w=7.7, color=GREEN)
    add_metric(slide, "票房缺失", f"{stats['missing']['票房']}部", 17.3, 3.0, w=6.0, color=GRAY)
    add_bullets(
        slide,
        [
            "《给阿嬷的情书》同时拿下票房与评分第一，形成口碑和商业表现共振。",
            "《错过了，遗憾吗？》票房下限进入前三，但评分仅4.5分，显示短期票房不等于口碑优势。",
            "22部影片缺少公开票房，整体规模只能按保守下限观察。",
        ],
        1.35,
        6.25,
        22.5,
        4.7,
        size=16,
    )

    # 3 Box office
    slide = prs.slides.add_slide(blank)
    add_title(slide, "票房榜：头部影片贡献最明显", "单位：万元；>=数据按可确认下限计入")
    box = stats["top_box"]
    add_bar_chart(
        slide,
        "票房Top5",
        [x["片名"] for x in box][::-1],
        [x["票房"] for x in box][::-1],
        1.25,
        2.8,
        16.2,
        9.4,
        color=RED,
    )
    add_bullets(
        slide,
        [
            f"Top1：{box[0]['片名']}，{fmt_money(box[0]['票房'])}，{box[0]['口径']}口径。",
            f"Top2：{box[1]['片名']}，{fmt_money(box[1]['票房'])}，{box[1]['口径']}口径。",
            "榜单含下限口径影片，真实排序可能随后续披露微调。",
        ],
        18.3,
        3.1,
        7.2,
        7.5,
        size=13,
    )

    # 4 Rating
    slide = prs.slides.add_slide(blank)
    add_title(slide, "评分榜：高口碑集中在家庭剧情与经典影片", "评分Top5均来自真实评分字段")
    ratings = stats["top_rating"]
    add_bar_chart(
        slide,
        "评分Top5",
        [x["片名"] for x in ratings][::-1],
        [x["评分"] for x in ratings][::-1],
        1.25,
        2.8,
        16.2,
        9.4,
        color=GREEN,
    )
    add_bullets(
        slide,
        [
            f"最高评分：{ratings[0]['片名']}，{fmt_score(ratings[0]['评分'])}。",
            "评分人数存在缺失，口碑稳定性仍需结合样本量观察。",
            "部分高分影片未披露票房，无法直接证明商业转化。",
        ],
        18.3,
        3.1,
        7.2,
        7.5,
        size=13,
    )

    # 5 Type distribution
    slide = prs.slides.add_slide(blank)
    add_title(slide, "类型分布：剧情覆盖最广，动画/冒险供给活跃", "多类型影片按每个类型标签分别计数")
    types = stats["types"][:8]
    add_bar_chart(
        slide,
        "类型影片数量Top8",
        [x["类型"] for x in types][::-1],
        [x["影片数量"] for x in types][::-1],
        1.2,
        2.8,
        17.0,
        9.5,
        color=BLUE,
    )
    add_bullets(
        slide,
        [
            f"剧情类{types[0]['影片数量']}部，是样本中最基础的供给底盘。",
            "动画、冒险均为6部，家庭观影和青少年向内容较活跃。",
            "类型均值受样本量影响较大，单片爆款会显著拉高平均票房。",
        ],
        19.0,
        3.0,
        6.3,
        7.6,
        size=13,
    )

    # 6 Region distribution
    slide = prs.slides.add_slide(blank)
    add_title(slide, "地区分布：中国大陆数量与票房贡献均居首", "合拍片按地区标签分别计数，非互斥口径")
    regions = stats["regions"][:6]
    add_pie_chart(
        slide,
        "制片地区数量分布",
        [x["制片地区"] for x in regions],
        [x["影片数量"] for x in regions],
        1.2,
        2.75,
        13.2,
        9.4,
    )
    add_bar_chart(
        slide,
        "地区总票房Top4（下限口径）",
        [x["制片地区"] for x in stats["regions"][:4]][::-1],
        [(x["总票房"] or 0) for x in stats["regions"][:4]][::-1],
        14.4,
        3.1,
        10.8,
        7.8,
        color=GOLD,
    )
    add_text(slide, "缺失票房按0显示在图中，仅用于可视化占位；汇总仍以缺失处理。", 14.5, 11.35, 10.8, 0.6, size=9, color=GRAY)

    # 7 Summary
    slide = prs.slides.add_slide(blank)
    add_title(slide, "总结：用保守口径看趋势，等待后续披露校准", "风险提示：缺失较多，不宜外推为完整市场结论")
    add_bullets(
        slide,
        [
            "可确认下限总票房为214,868.69万元，主要由少数头部影片贡献。",
            "《给阿嬷的情书》是样本内最强个案：票房第一、评分第一。",
            "票房和口碑存在分离案例，短期商业热度不能替代长期口碑判断。",
            "后续建议补齐精确票房、评分人数和连续日表现，再做排片或宣发复盘。",
        ],
        2.0,
        3.0,
        21.5,
        7.0,
        size=18,
    )
    add_text(slide, "一句话风险提示：当前结论受票房与评分缺失影响较大，只适合作为样本内趋势判断。", 2.0, 11.8, 22, 0.9, size=15, bold=True, color=RED)

    prs.save(PPTX_OUT)


def main():
    stats = json.loads(STATS_PATH.read_text(encoding="utf-8"))
    build_deck(stats)
    print(PPTX_OUT)


if __name__ == "__main__":
    main()
