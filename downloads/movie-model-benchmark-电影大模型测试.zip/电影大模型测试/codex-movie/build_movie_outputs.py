import json
import math
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt
from openpyxl import Workbook
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter


BASE_DIR = Path("/Users/chi/codex-movie")
SOURCE = Path("/Users/chi/Downloads/codex.xlsx")
XLSX_OUT = BASE_DIR / "movie_analysis.xlsx"
DOCX_OUT = BASE_DIR / "movie_report.docx"
STATS_OUT = BASE_DIR / "movie_stats.json"

MISSING_DATA = "暂无公开数据"
MISSING_RATING = "暂无公开评分"


def is_missing(value):
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    text = str(value).strip()
    return text == "" or text.lower() == "nan"


def clean_text(value, rating=False):
    if is_missing(value):
        return MISSING_RATING if rating else MISSING_DATA
    text = str(value).strip()
    if text in {"暂无", "无", "None"}:
        return MISSING_RATING if rating else MISSING_DATA
    return re.sub(r"\s+", " ", text)


def parse_date(value):
    if is_missing(value):
        return MISSING_DATA
    parsed = pd.to_datetime(value, errors="coerce")
    if pd.isna(parsed):
        return MISSING_DATA
    return parsed.strftime("%Y-%m-%d")


def parse_box_office(value):
    if is_missing(value):
        return None, "缺失"
    text = str(value).strip()
    if text == MISSING_DATA:
        return None, "缺失"
    lower = text.startswith(">=")
    numeric = re.sub(r"[^0-9.]", "", text)
    if numeric == "":
        return None, "缺失"
    return float(numeric), "下限" if lower else "精确"


def parse_rating(value):
    if is_missing(value):
        return None
    text = str(value).strip()
    if text == MISSING_RATING:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def parse_vote_count(value):
    if is_missing(value):
        return MISSING_DATA
    return str(value).strip()


def split_tokens(value):
    if is_missing(value):
        return []
    text = str(value).strip()
    if text in {MISSING_DATA, MISSING_RATING}:
        return []
    return [part.strip() for part in re.split(r"\s*/\s*", text) if part.strip()]


def money_fmt(value):
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "缺失"
    return f"{value:,.2f}"


def rating_fmt(value):
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "缺失"
    return f"{value:.1f}"


def load_clean_data():
    raw = pd.read_excel(SOURCE)
    rows = []
    seen = set()
    duplicate_count = 0
    for _, row in raw.iterrows():
        box_value, box_basis = parse_box_office(row.get("累计票房（万元）"))
        rating_value = parse_rating(row.get("评分（10分制）"))
        clean = {
            "片名": clean_text(row.get("片名")),
            "上映日期": parse_date(row.get("上映日期")),
            "类型": clean_text(row.get("类型")),
            "导演": clean_text(row.get("导演")),
            "主演": clean_text(row.get("主演")),
            "制片国家/地区": clean_text(row.get("制片国家/地区")),
            "时长": clean_text(row.get("时长")),
            "累计票房（万元）": clean_text(row.get("累计票房（万元）")),
            "票房口径": box_basis,
            "票房数值（万元，下限口径）": box_value,
            "评分（10分制）": clean_text(row.get("评分（10分制）"), rating=True),
            "评分数值": rating_value,
            "评分人数": parse_vote_count(row.get("评分人数")),
        }
        key = tuple(clean.items())
        if key in seen:
            duplicate_count += 1
            continue
        seen.add(key)
        rows.append(clean)
    return rows, duplicate_count, len(raw)


def compute_stats(rows, duplicate_count, raw_count):
    type_counter = Counter()
    region_counter = Counter()
    type_box = defaultdict(list)
    type_rating = defaultdict(list)
    region_box = defaultdict(float)
    missing = Counter()

    for row in rows:
        if row["票房数值（万元，下限口径）"] is None:
            missing["票房"] += 1
        if row["评分数值"] is None:
            missing["评分"] += 1
        if row["时长"] == MISSING_DATA:
            missing["时长"] += 1
        if row["评分人数"] == MISSING_DATA:
            missing["评分人数"] += 1

        for t in split_tokens(row["类型"]):
            type_counter[t] += 1
            if row["票房数值（万元，下限口径）"] is not None:
                type_box[t].append(row["票房数值（万元，下限口径）"])
            if row["评分数值"] is not None:
                type_rating[t].append(row["评分数值"])

        for r in split_tokens(row["制片国家/地区"]):
            region_counter[r] += 1
            if row["票房数值（万元，下限口径）"] is not None:
                region_box[r] += row["票房数值（万元，下限口径）"]

    top_box = sorted(
        [r for r in rows if r["票房数值（万元，下限口径）"] is not None],
        key=lambda x: x["票房数值（万元，下限口径）"],
        reverse=True,
    )[:5]
    top_rating = sorted(
        [r for r in rows if r["评分数值"] is not None],
        key=lambda x: x["评分数值"],
        reverse=True,
    )[:5]
    exact_box_total = sum(r["票房数值（万元，下限口径）"] for r in rows if r["票房数值（万元，下限口径）"] is not None)
    exact_count = sum(1 for r in rows if r["票房口径"] == "精确")
    lower_count = sum(1 for r in rows if r["票房口径"] == "下限")

    types = sorted(type_counter.keys(), key=lambda k: (-type_counter[k], k))
    regions = sorted(region_counter.keys(), key=lambda k: (-region_counter[k], k))

    return {
        "source": str(SOURCE),
        "raw_count": raw_count,
        "valid_count": len(rows),
        "duplicate_count": duplicate_count,
        "missing": dict(missing),
        "box_office_total_lower_bound": exact_box_total,
        "box_office_exact_count": exact_count,
        "box_office_lower_bound_count": lower_count,
        "scored_count": sum(1 for r in rows if r["评分数值"] is not None),
        "types": [
            {
                "类型": t,
                "影片数量": type_counter[t],
                "平均票房": sum(type_box[t]) / len(type_box[t]) if type_box[t] else None,
                "平均评分": sum(type_rating[t]) / len(type_rating[t]) if type_rating[t] else None,
            }
            for t in types
        ],
        "regions": [
            {
                "制片地区": r,
                "影片数量": region_counter[r],
                "总票房": region_box[r] if region_box[r] else None,
            }
            for r in regions
        ],
        "top_box": [
            {
                "片名": r["片名"],
                "票房": r["票房数值（万元，下限口径）"],
                "口径": r["票房口径"],
                "评分": r["评分数值"],
            }
            for r in top_box
        ],
        "top_rating": [
            {
                "片名": r["片名"],
                "评分": r["评分数值"],
                "票房": r["票房数值（万元，下限口径）"],
                "口径": r["票房口径"],
            }
            for r in top_rating
        ],
    }


def build_xlsx(rows, stats):
    wb = Workbook()
    ws = wb.active
    ws.title = "清洗后数据"
    headers = list(rows[0].keys()) + ["票房排名辅助", "评分排名辅助"]
    ws.append(headers)
    for idx, row in enumerate(rows, start=2):
        ws.append([row[h] for h in list(rows[0].keys())] + [f'=IF(J{idx}="","",J{idx}+ROW()/1000000000)', f'=IF(L{idx}="","",L{idx}+ROW()/1000000000)'])

    ws.freeze_panes = "A2"
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = border
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    for col in range(1, len(headers) + 1):
        letter = get_column_letter(col)
        max_len = max(len(str(ws.cell(r, col).value or "")) for r in range(1, ws.max_row + 1))
        ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 32)
    ws.column_dimensions["N"].hidden = True
    ws.column_dimensions["O"].hidden = True
    for col_name in ["票房数值（万元，下限口径）"]:
        idx = headers.index(col_name) + 1
        for cell in ws.iter_cols(min_col=idx, max_col=idx, min_row=2, max_row=ws.max_row):
            for c in cell:
                c.number_format = '#,##0.00'
                c.alignment = Alignment(horizontal="right")
    for col_name in ["评分数值"]:
        idx = headers.index(col_name) + 1
        for cell in ws.iter_cols(min_col=idx, max_col=idx, min_row=2, max_row=ws.max_row):
            for c in cell:
                c.number_format = '0.0'
                c.alignment = Alignment(horizontal="right")
    ws.auto_filter.ref = ws.dimensions

    st = wb.create_sheet("统计分析")
    st.sheet_view.showGridLines = False
    st["A1"] = "统计说明"
    st["A2"] = "票房为“可确认下限口径”：精确票房按原值，>=票房按下限值；缺失不参与均值和排名。"
    st["A3"] = "总样本量"
    st["B3"] = "=COUNTA('清洗后数据'!A:A)-1"
    st["A4"] = "可确认下限总票房（万元）"
    st["B4"] = "=SUM('清洗后数据'!J:J)"
    st["A5"] = "有评分影片数"
    st["B5"] = "=COUNT('清洗后数据'!L:L)"
    st["D1"] = "按类型的平均票房与平均评分"
    type_start = 2
    type_headers = ["类型", "影片数量", "平均票房（万元）", "平均评分"]
    for i, h in enumerate(type_headers, 4):
        st.cell(type_start, i, h)
    for r_idx, item in enumerate(stats["types"], type_start + 1):
        st.cell(r_idx, 4, item["类型"])
        st.cell(r_idx, 5, f'=COUNTIF(\'清洗后数据\'!$C:$C,"*"&D{r_idx}&"*")')
        st.cell(r_idx, 6, f'=IFERROR(AVERAGEIF(\'清洗后数据\'!$C:$C,"*"&D{r_idx}&"*",\'清洗后数据\'!$J:$J),"缺失")')
        st.cell(r_idx, 7, f'=IFERROR(AVERAGEIF(\'清洗后数据\'!$C:$C,"*"&D{r_idx}&"*",\'清洗后数据\'!$L:$L),"缺失")')

    top_start = type_start + len(stats["types"]) + 3
    st.cell(top_start, 1, "票房 Top5（可确认下限口径）")
    top_headers = ["排名", "片名", "票房（万元）", "票房口径", "评分"]
    for i, h in enumerate(top_headers, 1):
        st.cell(top_start + 1, i, h)
    for i in range(5):
        rr = top_start + 2 + i
        st.cell(rr, 1, i + 1)
        st.cell(rr, 2, f'=IFERROR(INDEX(\'清洗后数据\'!$A:$A,MATCH(LARGE(\'清洗后数据\'!$N:$N,A{rr}),\'清洗后数据\'!$N:$N,0)),"缺失")')
        st.cell(rr, 3, f'=IFERROR(INDEX(\'清洗后数据\'!$J:$J,MATCH(LARGE(\'清洗后数据\'!$N:$N,A{rr}),\'清洗后数据\'!$N:$N,0)),"缺失")')
        st.cell(rr, 4, f'=IFERROR(INDEX(\'清洗后数据\'!$I:$I,MATCH(LARGE(\'清洗后数据\'!$N:$N,A{rr}),\'清洗后数据\'!$N:$N,0)),"缺失")')
        st.cell(rr, 5, f'=IFERROR(INDEX(\'清洗后数据\'!$L:$L,MATCH(LARGE(\'清洗后数据\'!$N:$N,A{rr}),\'清洗后数据\'!$N:$N,0)),"缺失")')

    rating_start = top_start
    st.cell(rating_start, 7, "评分 Top5")
    rating_headers = ["排名", "片名", "评分", "票房（万元）", "票房口径"]
    for i, h in enumerate(rating_headers, 7):
        st.cell(rating_start + 1, i, h)
    for i in range(5):
        rr = rating_start + 2 + i
        st.cell(rr, 7, i + 1)
        st.cell(rr, 8, f'=IFERROR(INDEX(\'清洗后数据\'!$A:$A,MATCH(LARGE(\'清洗后数据\'!$O:$O,G{rr}),\'清洗后数据\'!$O:$O,0)),"缺失")')
        st.cell(rr, 9, f'=IFERROR(INDEX(\'清洗后数据\'!$L:$L,MATCH(LARGE(\'清洗后数据\'!$O:$O,G{rr}),\'清洗后数据\'!$O:$O,0)),"缺失")')
        st.cell(rr, 10, f'=IFERROR(INDEX(\'清洗后数据\'!$J:$J,MATCH(LARGE(\'清洗后数据\'!$O:$O,G{rr}),\'清洗后数据\'!$O:$O,0)),"缺失")')
        st.cell(rr, 11, f'=IFERROR(INDEX(\'清洗后数据\'!$I:$I,MATCH(LARGE(\'清洗后数据\'!$O:$O,G{rr}),\'清洗后数据\'!$O:$O,0)),"缺失")')

    region_start = top_start + 9
    st.cell(region_start, 1, "各制片地区的影片数量与总票房")
    region_headers = ["制片地区", "影片数量", "总票房（万元，下限口径）"]
    for i, h in enumerate(region_headers, 1):
        st.cell(region_start + 1, i, h)
    for i, item in enumerate(stats["regions"], region_start + 2):
        st.cell(i, 1, item["制片地区"])
        st.cell(i, 2, f'=SUMPRODUCT(--ISNUMBER(SEARCH(A{i},\'清洗后数据\'!$F$2:$F${len(rows)+1})))')
        st.cell(i, 3, f'=SUMPRODUCT(--ISNUMBER(SEARCH(A{i},\'清洗后数据\'!$F$2:$F${len(rows)+1})),\'清洗后数据\'!$J$2:$J${len(rows)+1})')

    for row in st.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    header_cells = [st[1], st[2], st[top_start + 1], st[rating_start + 1], st[region_start + 1]]
    for row in header_cells:
        for cell in row:
            if cell.value:
                cell.font = Font(bold=True)
                cell.fill = PatternFill("solid", fgColor="D9EAF7")
                cell.border = border
    for cell in [st["A1"], st["D1"], st.cell(top_start, 1), st.cell(rating_start, 7), st.cell(region_start, 1)]:
        cell.font = Font(bold=True, size=13, color="1F4E78")
    for col in range(1, 12):
        st.column_dimensions[get_column_letter(col)].width = 18
    for col in ["B", "C", "F", "J"]:
        for cell in st[col]:
            cell.number_format = '#,##0.00'
            cell.alignment = Alignment(horizontal="right")
    for col in ["G", "I"]:
        for cell in st[col]:
            cell.number_format = '0.0'
            cell.alignment = Alignment(horizontal="right")
    st["B3"].number_format = '0'
    st["B5"].number_format = '0'
    st.freeze_panes = "A2"

    # Native charts on the analysis sheet for quick visual checking.
    type_chart = BarChart()
    type_chart.title = "类型影片数量 Top8"
    type_chart.y_axis.title = "影片数量"
    type_chart.x_axis.title = "类型"
    type_data = Reference(st, min_col=5, min_row=2, max_row=min(type_start + 8, type_start + len(stats["types"])))
    type_cats = Reference(st, min_col=4, min_row=3, max_row=min(type_start + 8, type_start + len(stats["types"])))
    type_chart.add_data(type_data, titles_from_data=True)
    type_chart.set_categories(type_cats)
    type_chart.width = 14
    type_chart.height = 7
    st.add_chart(type_chart, "M2")

    region_chart = PieChart()
    region_chart.title = "制片地区数量分布"
    reg_data = Reference(st, min_col=2, min_row=region_start + 1, max_row=region_start + min(8, len(stats["regions"])) + 1)
    reg_cats = Reference(st, min_col=1, min_row=region_start + 2, max_row=region_start + min(8, len(stats["regions"])) + 1)
    region_chart.add_data(reg_data, titles_from_data=True)
    region_chart.set_categories(reg_cats)
    region_chart.width = 12
    region_chart.height = 7
    st.add_chart(region_chart, "M18")

    wb.save(XLSX_OUT)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def build_docx(rows, stats):
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Cm(2.2)
    sec.bottom_margin = Cm(2.2)
    sec.left_margin = Cm(2.5)
    sec.right_margin = Cm(2.5)
    styles = doc.styles
    styles["Normal"].font.name = "Microsoft YaHei"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    styles["Normal"].font.size = Pt(11)
    for style_name in ["Heading 1", "Heading 2", "Title"]:
        styles[style_name].font.name = "Microsoft YaHei"
        styles[style_name]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")

    title = doc.add_heading("2026年5月新片数据分析报告", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph(f"数据来源：{SOURCE.name}；生成日期：{datetime.now().strftime('%Y-%m-%d')}")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("一、概述", level=1)
    doc.add_paragraph(
        f"本报告基于《codex.xlsx》中“recent_movies_2026-05-30”工作表加工而成，原始样本为{stats['raw_count']}条，"
        f"清洗后保留{stats['valid_count']}条有效记录，未发现完全重复记录。清洗动作包括去除字段首尾空格、统一上映日期为YYYY-MM-DD、"
        "将空白或不可识别字段标注为“暂无公开数据/暂无公开评分”，并保留原始票房口径。数据覆盖2026年4月30日至2026年5月30日上映或待映影片，"
        "字段包括片名、上映日期、类型、导演、主演、制片国家/地区、时长、累计票房、评分与评分人数。"
    )
    doc.add_paragraph(
        f"数据质量方面，票房缺失较明显：{stats['missing']['票房']}部影片没有公开票房，另有{stats['box_office_lower_bound_count']}部只提供“>=”下限口径；"
        f"评分缺失{stats['missing']['评分']}部，时长缺失{stats['missing']['时长']}部，评分人数缺失{stats['missing']['评分人数']}部。"
        "因此，本报告涉及票房总量时统一使用“可确认下限票房”口径，即精确票房按原值计入，带有“>=”符号的票房只按下限计入，缺失值不补零、不估算。"
    )

    doc.add_heading("二、核心指标", level=1)
    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    for i, h in enumerate(["指标", "数值", "指标", "数值"]):
        hdr[i].text = h
        set_cell_shading(hdr[i], "D9EAF7")
    metrics = [
        ("样本量", f"{stats['valid_count']}部", "有评分影片", f"{stats['scored_count']}部"),
        ("可确认下限总票房", f"{money_fmt(stats['box_office_total_lower_bound'])}万元", "票房Top1", stats["top_box"][0]["片名"]),
        ("评分Top1", stats["top_rating"][0]["片名"], "最高评分", rating_fmt(stats["top_rating"][0]["评分"])),
    ]
    for row in metrics:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = value

    doc.add_heading("三、票房表现分析", level=1)
    doc.add_paragraph(
        f"在可统计票房的影片中，累计可确认下限票房为{money_fmt(stats['box_office_total_lower_bound'])}万元。"
        f"《{stats['top_box'][0]['片名']}》以{money_fmt(stats['top_box'][0]['票房'])}万元位居第一，明显高于第二名《{stats['top_box'][1]['片名']}》"
        f"的{money_fmt(stats['top_box'][1]['票房'])}万元，说明样本中的票房贡献呈头部集中。"
        "需要注意的是，榜单中既有精确数值，也有下限口径；例如部分影片只披露“>=5000万元”，实际规模可能更高，"
        "但在不编造数据的前提下，只能按已确认下限进行比较。"
    )
    doc.add_paragraph(
        "票房Top5显示，国产剧情、悬疑犯罪、动画冒险以及海外续作共同出现在高位，并非单一类型垄断。"
        "其中《给阿嬷的情书》和《消失的人》拥有精确票房，分别代表高口碑家庭剧情和较强商业类型片；"
        "《错过了，遗憾吗？》《寒战1994》《10间敢死队》等下限口径影片则提示市场热度存在，但精确表现仍需后续数据确认。"
    )

    doc.add_heading("四、评分与口碑分析", level=1)
    doc.add_paragraph(
        f"评分维度共有{stats['scored_count']}部影片可用于比较，最高为《{stats['top_rating'][0]['片名']}》的{rating_fmt(stats['top_rating'][0]['评分'])}分，"
        f"其次是《{stats['top_rating'][1]['片名']}》{rating_fmt(stats['top_rating'][1]['评分'])}分和《{stats['top_rating'][2]['片名']}》{rating_fmt(stats['top_rating'][2]['评分'])}分。"
        "高分影片中既有新片，也有经典影片或续作类项目，这会使评分榜更偏向已积累观众认知和样本量的影片。"
        "评分人数的缺失同样会影响稳定性：有些影片有评分但没有公开评分人数，口碑可信度需要结合样本规模一起判断。"
    )
    doc.add_paragraph(
        f"票房与评分的关系并不完全同步。最典型的是《{stats['top_box'][0]['片名']}》同时拥有最高票房和最高评分，"
        "说明在本样本中存在“商业表现与口碑共振”的个案；但《错过了，遗憾吗？》的可确认下限票房进入前列，评分却只有4.5分，"
        "显示营销声量、题材热度或排片窗口可以推动短期票房，而口碑未必同步。反过来，《记忆碎片》《纵横四海》等评分高的影片并未披露票房，"
        "也说明口碑价值和当前可观测票房之间受到发行时点、重映属性、数据披露程度等因素干扰。"
    )

    doc.add_heading("五、类型与地区分布", level=1)
    top_types = "、".join([f"{x['类型']}({x['影片数量']}部)" for x in stats["types"][:5]])
    top_regions = "、".join([f"{x['制片地区']}({x['影片数量']}部)" for x in stats["regions"][:5]])
    doc.add_paragraph(
        f"类型分布上，样本最集中的类型为{top_types}。剧情片覆盖面最广，既包含爱情、家庭、儿童等现实向表达，"
        "也与犯罪、战争、运动等子类型结合；动画和冒险类影片数量也较多，说明5月末档期对家庭观影和青少年观众仍有供给。"
        "从平均评分看，带有经典片、家庭片或成熟类型片属性的影片更容易占据高位，但部分类型因为样本量小，均值容易被单片拉动。"
    )
    doc.add_paragraph(
        f"地区分布上，主要来源包括{top_regions}。中国大陆影片数量最多，同时贡献了大部分可确认票房；美国、英国、爱尔兰等地区多以合拍或进口片形式出现。"
        "地区总票房同样采用可确认下限口径，含合拍片时会按地区标签分别计数，因此地区数量不是互斥口径。"
        "这能帮助观察市场供给结构，但不宜直接等同于各地区单独投资收益。"
    )

    doc.add_heading("六、结论与风险提示", level=1)
    doc.add_paragraph(
        "总体来看，本批影片呈现出“供给分散、票房头部集中、评分分化明显”的特征。"
        "商业表现最强的影片不一定只有类型片，高口碑家庭剧情同样可能形成票房优势；但票房披露缺失较多，使得整体市场规模只能以保守下限观察。"
        "后续若用于排片、宣发复盘或投资判断，应优先补齐精确票房、评分人数和上映后连续日表现。"
    )
    doc.add_paragraph("一句话风险提示：当前结论受票房与评分缺失影响较大，只适合作为样本内趋势判断，不宜外推为完整市场结论。")

    doc.save(DOCX_OUT)


def main():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    rows, duplicate_count, raw_count = load_clean_data()
    stats = compute_stats(rows, duplicate_count, raw_count)
    build_xlsx(rows, stats)
    build_docx(rows, stats)
    STATS_OUT.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"xlsx": str(XLSX_OUT), "docx": str(DOCX_OUT), "stats": str(STATS_OUT)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
